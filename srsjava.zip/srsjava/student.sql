﻿# Host: 127.0.0.1  (Version: 5.5.15)
# Date: 2017-07-04 21:28:37
# Generator: MySQL-Front 5.3  (Build 4.269)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "course"
#

DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `cno` int(11) NOT NULL DEFAULT '0',
  `cname` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `credit` int(11) DEFAULT NULL,
  `tno` int(11) DEFAULT NULL,
  `tname` varchar(15) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  PRIMARY KEY (`cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "course"
#

INSERT INTO `course` VALUES (1,'HTML+CSS基础课程','本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',3,1,'大漠',30),(2,'JavaScript入门','快速认识JavaScript，熟悉JavaScript基本语法、窗口交互方法和通过DOM进行网页元素的操作，学会如何编写JS代码，如何运用JavaScript去操作HTML元素和CSS样式',3,1,'大漠',30),(3,'Bootstrap框架','ABootstrap框架是一个非常受欢迎的前端开发框架，他能让后端程序员和不懂设计的前端人员制作出优美的Web页面或Web应用程序。在这个Bootstrap教程中，将带领大家了解Bootstrap框架以及如何使用Bootstrap框架，通过本教程学习能够独立定制出适合自己的Bootstrap',3,2,'Aaron艾伦',30),(4,'jQuery入门','jQuery基础课程总共分为4个部分，分别是样式篇、事件篇、动画篇、DOM篇。此为第一个部分—样式篇，本课程主要介绍jQuery的基础语法，选择器以及jQuery的一些属性和样式，通过本课程的学习，我们可以用最少的代码做更多的事，让我们一起出发学习吧！',3,3,'fishenal',30),(5,'Vue.js入门','本课程主要讲解了vuejs 是如何站在前端巨人肩膀上，进行新项目的搭建，教程中通过一个简单的todolist讲解vuejs基本用法和常用接口。',3,4,'Materliu',30),(6,'React入门','学习React出现的背景，React自身的优势与不足，同jQuery, AngularJS等库和框架相比差异点在哪里。React教程分为：React入门\"、\"React实践图片画廊应用(上)\"、\"React实践图片画廊应用(下)\"三门课程，该教程是第一门教程。',3,5,'余博伦',30),(7,'Java入门','学习Java基础知识，为之后的J2EE打下基础',3,6,'how2java',30),(8,'J2EE','Java 2 Platform Enterprise Edition，J2EE是一套全然不同于传统应用开发的技术架构，包含许多组件，主要可简化且规范应用系统的开发与部署，进而提高可移植性、安全与再用价值。',3,6,'how2java',30),(9,'Java框架集SSM','SSM（Spring+SpringMVC+MyBatis）框架集由Spring、SpringMVC、MyBatis三个开源框架整合而成，常作为数据源较简单的web项目的框架。',3,6,'how2java',30),(10,'数据库概论及MySQL','与其他的大型数据库LAMPLAMP例如 Oracle、DB2、SQL Server等相比，MySQL 自有它的不足之处，但是这丝毫也没有减少它受欢迎的程度。对于一般的个人使用者和中小型企业来说，MySQL提供的功能已经绰绰有余，而且由于 MySQL是开放源码软件，因此可以大大降低总体拥有成本。',3,7,'Oracle',30),(123,'123',NULL,1,123,'123',123);

#
# Structure for table "sc"
#

DROP TABLE IF EXISTS `sc`;
CREATE TABLE `sc` (
  `sno` int(11) NOT NULL DEFAULT '0',
  `cno` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sno`,`cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "sc"
#

INSERT INTO `sc` VALUES (110,1),(1030415601,1),(1030415602,1),(1030415603,1),(1030415604,1),(1030415605,1),(1030415606,1),(1030415607,1),(1030415608,1),(1030415609,1),(1030415610,1),(1030415611,1),(1030415612,1),(1030415613,1),(1030415614,1),(1030415615,1),(1030415616,1),(1030415617,1),(1030415618,1),(1030415619,1),(1030415620,1),(1030415621,1),(1030415622,1),(1030415623,1),(1030415624,1),(1030415625,1),(1030415626,8),(1030415626,9),(1030415626,10),(1030415627,1),(1030415628,1),(1030415629,1),(1030415630,1);

#
# Structure for table "selection"
#

DROP TABLE IF EXISTS `selection`;
CREATE TABLE `selection` (
  `sno` int(11) NOT NULL DEFAULT '0',
  `cno` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sno`,`cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "selection"
#

INSERT INTO `selection` VALUES (1030415626,1),(1030415626,3),(1030415626,5);

#
# Structure for table "student"
#

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `sno` int(11) NOT NULL DEFAULT '0',
  `sname` varchar(255) DEFAULT NULL,
  `major` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "student"
#

INSERT INTO `student` VALUES (1030415601,'尹璐','计算机科学与技术'),(1030415602,'','计算机科学与技术'),(1030415603,'','计算机科学与技术'),(1030415604,'','计算机科学与技术'),(1030415605,'','计算机科学与技术'),(1030415606,'','计算机科学与技术'),(1030415607,'','计算机科学与技术'),(1030415608,'','计算机科学与技术'),(1030415609,'','计算机科学与技术'),(1030415610,'','计算机科学与技术'),(1030415611,'','计算机科学与技术'),(1030415612,'','计算机科学与技术'),(1030415613,'','计算机科学与技术'),(1030415614,'','计算机科学与技术'),(1030415615,'','计算机科学与技术'),(1030415616,'','计算机科学与技术'),(1030415617,'','计算机科学与技术'),(1030415618,'','计算机科学与技术'),(1030415619,'','计算机科学与技术'),(1030415620,'','计算机科学与技术'),(1030415621,'','计算机科学与技术'),(1030415622,'','计算机科学与技术'),(1030415623,'','计算机科学与技术'),(1030415624,'','计算机科学与技术'),(1030415625,'','计算机科学与技术'),(1030415626,'','计算机科学与技术'),(1030415627,'','计算机科学与技术'),(1030415628,'','计算机科学与技术'),(1030415629,'','计算机科学与技术'),(1030415630,'','计算机科学与技术');

#
# Structure for table "teacher"
#

DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `tno` int(11) NOT NULL DEFAULT '0',
  `tname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "teacher"
#

INSERT INTO `teacher` VALUES (1,'大漠'),(2,'Aaron艾伦'),(3,'fishenal'),(4,'Materliu'),(5,'余博伦'),(6,'how2java'),(7,'Oracle');

#
# Structure for table "user"
#

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(11) NOT NULL DEFAULT '0',
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `level` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "user"
#

INSERT INTO `user` VALUES ('1','1','大漠','teacher'),('1030415601','1030415601','尹璐','student'),('1030415602','1030415602','徐娅琪','student'),('1030415603','1030415603','施芹','student'),('1030415604','1030415604','刘锦','student'),('1030415605','1030415605','尹东欣','student'),('1030415606','1030415606','陈科宇','student'),('1030415607','1030415607','邓锦辉','student'),('1030415608','1030415608','王良利','student'),('1030415609','1030415609','李月月','student'),('1030415610','1030415610','王佳睿','student'),('1030415611','1030415611','李素芳','student'),('1030415612','1030415612','陈旺','student'),('1030415613','1030415613','王震','student'),('1030415614','1030415614','方超','student'),('1030415615','1030415615','严林林','student'),('1030415616','1030415616','顾耿亮','student'),('1030415617','1030415617','郭浩宇','student'),('1030415618','1030415618','曾彦凯','student'),('1030415619','1030415619','曹文涛','student'),('1030415620','1030415620','崔方正','student'),('1030415621','1030415621','丁潇潇','student'),('1030415622','1030415622','温名阳','student'),('1030415623','1030415623','刘庆','student'),('1030415624','1030415624','都书晨','student'),('1030415625','1030415625','李永杰','student'),('1030415626','1030415626','殷贵庆','student'),('1030415627','1030415627','谌杨','admin'),('1030415628','1030415628','汪启扬','student'),('1030415629','1030415629','杨屏藩','student'),('1030415630','1030415630','吕行','student'),('1030415631','1030415631','袁沪生','student'),('1030415633','1030415633','张昕宇','student'),('11','11','11','student'),('123123','123123','123123123','student'),('2','2','Aaron艾伦','teacher'),('3','3','fishenal','teacher'),('4','4','Materliu','teacher'),('5','5','余博伦','teacher'),('6','6','how2java','teacher'),('7','7','Oracle','teacher');
